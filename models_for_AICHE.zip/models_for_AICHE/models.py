from constants import *

import tensorflow as tf

physical_devices = tf.config.list_physical_devices('GPU')

for device in physical_devices:
    try:
        tf.config.experimental.set_memory_growth(device, True)
    except:
        continue

from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense, Dropout, BatchNormalization, Activation, Embedding,Flatten,Masking
from tensorflow.keras.layers import Conv1D, GlobalMaxPooling1D, SpatialDropout1D
from tensorflow.keras.layers import Concatenate
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.regularizers import l2

import numpy as np
import json
from tqdm import tqdm

import warnings
import matplotlib.pyplot as plt
plt.switch_backend('agg')

class Conv1DPredictor(object):
    def ConvLayer(self, kernel_size, filters, dilation_rate, activation, initializer, regularizer_param, use_batchnorm = True, conv_dropout = 0.2, padding='same'):
        def f(input):
            model_p = Conv1D(filters=filters, kernel_size=kernel_size, padding=padding, kernel_initializer=initializer, kernel_regularizer=l2(regularizer_param),dilation_rate=dilation_rate)(input)
            model_p = BatchNormalization()(model_p)
            model_p = Activation(activation)(model_p)
            model_p = GlobalMaxPooling1D()(model_p)
            return Dropout(conv_dropout)(model_p)
        return f

    def build_model(self, 
                    protein_feat_length=1024, protein_feat_depth=25, 
                    substrate_feat_length=2048, substrate_feat_depth = 1, 
                    substrate_fc_layers=256, protein_fc_layers=None, 
                    output_fc_layers=256, 
                    protein_fc_dropout = 0.0, substrate_fc_dropout=0.0, 
                    output_fc_dropout = 0.0, conv_dropout = 0.2,
                    learning_rate=0.0001, 
                    activation='relu', 
                    regularizer_param = 0.001, 
                    initializer="glorot_normal", 
                    batch_size=64, 
                    epochs = 30, 
                    loss='mean_squared_error', 
                    use_batch_norm=False,
                    protein_filters = 32, 
                    protein_kernel_sizes = [5],
                    dilation_rate=1):
                
        def _return_tuple(value):
            if type(value) is int:
                return [value]
            else:
                return tuple(value)
          
        if substrate_feat_depth>1:
            input_sub = Input(shape=(substrate_feat_length,substrate_feat_depth,)) 
            input_sub = tensorflow.keras.layers.Flatten()(input_sub)
        else:
            input_sub = Input(shape=(substrate_feat_length,))
        
        params_dic = {"kernel_initializer": initializer,
                      "kernel_regularizer": l2(regularizer_param)}

        model_sub = input_sub
        if substrate_fc_layers is not None:
            substrate_fc_layers = _return_tuple(substrate_fc_layers)
            for layer_size in substrate_fc_layers:
                model_sub = Dense(layer_size, **params_dic)(model_sub)
                model_sub = Activation(activation)(model_sub)
                if use_batch_norm: 
                    model_sub = BatchNormalization()(model_sub)
                model_sub = Dropout(substrate_fc_dropout)(model_sub)
                input_layer_sub = model_sub

        input_prot = Input(shape=(protein_feat_length,protein_feat_depth)) 
        model_prot = input_prot
        
        # model_prot = Masking(-999999.)(model_prot)
        model_convs = [self.ConvLayer(kernel_size, protein_filters, dilation_rate, activation, initializer, regularizer_param,use_batch_norm)(model_prot) for kernel_size in protein_kernel_sizes]
        
        if len(model_convs)!=1:
            model_prot = Concatenate(axis=1)(model_convs)
        else:
            model_prot = model_convs[0]
            
        if protein_fc_layers:
            input_layer_prot = model_prot
            protein_fc_layers = _return_tuple(protein_fc_layers)
            for layer in protein_fc_layers:
                model_prot = Dense(layer, **params_dic)(input_layer_prot)
                model_prot = Activation(activation)(model_prot)
                if use_batch_norm:
                    model_prot = BatchNormalization()(model_prot)
                model_prot = Dropout(protein_fc_dropout)(model_prot)
                input_layer_prot = model_prot
        
        model_output = Concatenate(axis=1)([model_sub,model_prot])
        if output_fc_layers is not None:
            output_fc_layers = _return_tuple(output_fc_layers)
            for fc_layer in output_fc_layers:
                model_output = Dense(units=fc_layer, **params_dic)(model_output)
                model_output = Activation(activation)(model_output)
                if use_batch_norm:
                    model_output = BatchNormalization()(model_output)
                model_output = Dropout(output_fc_dropout)(model_output)
        
        # final_bias_initializer = tf.keras.initializers.RandomNormal(mean=0.0, stddev=3.0)
        model_output = Dense(1, activation='linear', activity_regularizer=l2(regularizer_param),
                         # bias_initializer=final_bias_initializer,
                         kernel_initializer=initializer
                        )(model_output)

        model = Model(inputs=[input_sub, input_prot], outputs = model_output)

        return model
    
    def __init__(self, params):
        print('*'*50)
        print('         Bulding Model        ')
        print('*'*50)
        self.params = params
        self.history = None
        # with strategy.scope():
        self.modelobj = self.build_model(**params)
        #print(self.summary())
        opt = Adam(learning_rate=params["learning_rate"])
        loss = tf.keras.losses.MeanSquaredError(reduction="auto", name="mean_squared_error")
        self.modelobj.compile(optimizer=opt, loss=loss, metrics=['mean_squared_error', 'mean_absolute_error'])#,run_eagerly=True)
        print(self.summary())
        
    def summary(self):
        self.modelobj.summary()
        
    def train(self, train_dataset, validation_dataset, epochs, save_prefix, full_fold=False):
        
        print('*'*50)
        print('         Training Model        ')
        print('*'*50)
        
        # early stopping
        es = tf.keras.callbacks.EarlyStopping(monitor='val_loss', mode='min', verbose=1, patience=6)

        # model checkpoint
        mc = tf.keras.callbacks.ModelCheckpoint(save_prefix + '_best_train_model.h5', monitor='val_loss', mode='min', verbose=1, save_best_only=True)

        if full_fold: 
            # fit model
            reduce_cb = tf.keras.callbacks.ReduceLROnPlateau(
                        monitor=f'loss',
                        factor=0.1,
                        patience=5,
                        min_lr=1e-6,
                        mode='min',
                    )
            mc = tf.keras.callbacks.ModelCheckpoint(save_prefix + '_best_train_model.h5', monitor='loss', mode='min', verbose=1, save_best_only=True)
            history = self.modelobj.fit(train_dataset,
                                     epochs=epochs,
                                     callbacks=[mc,reduce_cb])
        else:
            # fit model
            reduce_cb = tf.keras.callbacks.ReduceLROnPlateau(
                        monitor=f'val_loss',
                        factor=0.1,
                        patience=5,
                        min_lr=1e-6,
                        mode='min',
                    )
            history = self.modelobj.fit(train_dataset,
                                     epochs=epochs,
                                     validation_data=validation_dataset,
                                     callbacks=[es, mc, reduce_cb])

        self.history = history.history

    def predict(self, inputs, batch_size=1):
        print('Predicting..')
        return self.modelobj.predict(inputs, batch_size=batch_size, use_multiprocessing=True)
    
    def evaluate(self, predict_ds, batch_size, return_preds_labels=True):
        print('*'*50)
        print('         Evaluating Model        ')
        print('*'*50)
        
        preds_list = []
        labels_list = []
        
        # preds = self.predict(predict_x_ds, batch_size=100)
        
        for _inputs, _labels in tqdm(predict_ds.take(-1)):
            preds = self.modelobj.predict(_inputs, batch_size=1000, use_multiprocessing=True)
            print(preds.shape)
            preds_list.extend([*preds])
            labels_list.extend([*_labels])
                        
        metrics = {}
        
        labels_list = np.array(labels_list).flatten()
        preds_list = np.array(preds_list).flatten()
        
        print(labels_list.shape, preds_list.shape)
        print(f'Min pred value: {min(preds_list)}')
        print(f'Max pred value: {max(preds_list)}')
        print(f'Min label value: {min(labels_list)}')
        print(f'Max label value: {max(labels_list)}')
        
        
        metrics['R2'] = r2_score(labels_list, preds_list)
        p = pearsonr(labels_list, preds_list)
        metrics['r'] = p[0]
        metrics['r_P'] = p[1]
        metrics['mse'] = mean_squared_error(labels_list, preds_list)
        metrics['rmse'] = np.sqrt(metrics['mse'])
        metrics['mape'] = mean_absolute_percentage_error(labels_list, preds_list)
        metrics['mae'] = abs(np.average(labels_list - preds_list))
        
        if return_preds_labels:
            return metrics, {'preds': preds_list, 'labels': labels_list}
        
        return metrics
    
    def plot_losses(self):
        plt.figure()
        plt.plot(self.history[f'train {self.loss}'], '-')
        plt.plot(self.history[f'val {self.loss}'], '-')
        plt.title('model loss')
        plt.ylabel('loss')
        plt.xlabel('epoch')
        plt.legend(['train', 'validation'], loc='upper left')
        plt.savefig(self.model_name_prefix + '_model_loss.png', bbox_inches='tight')

    def save_model(self):
        self.model.save(self.model_name_prefix + '.hdf5')

    def load_model(self, model_path):
        self.model = tf.keras.models.load_model(model_path)
        
